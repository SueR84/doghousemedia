---
title: "Promotional for Pharmaceutical"
client: "Amgen"
year: 2024
craft: "video"
summary: "Internal informational video created for Amgen documenting their €300m expansion project in Dublin."
video: "0872"
services:
  - "Informational video"
order: 20
draft: false
---
In 2015 Amgen opened their state of the art facility in south Co. Dublin. This short informational film documents their recent $300m expansion and the new production facilities added to the existing plant.
