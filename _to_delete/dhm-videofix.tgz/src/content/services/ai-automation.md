---
index: "003"
title: AI automation
description: Taking the repetitive parts of a working week and handing them to a machine. Document handling, triage, drafting and internal tooling, scoped so it saves real hours.
categories: [Process audit, Workflow automation, Document processing, Internal tools, Training]
order: 3
---
