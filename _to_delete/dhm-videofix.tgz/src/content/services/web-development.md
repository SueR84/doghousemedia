---
index: "001"
title: Web design and development
description: Fast, accessible sites built to be maintained. WordPress when a client needs to edit everything themselves, Astro when speed matters more than a page builder.
categories: [Discovery, UX and wireframes, Design, Build, Migration, Hosting and support]
order: 1
---
