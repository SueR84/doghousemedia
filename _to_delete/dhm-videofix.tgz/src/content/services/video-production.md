---
index: "004"
title: Video production
description: Corporate film, case studies and content shot and cut in-house. The same studio that builds the site cuts the film that goes on it.
categories: [Concept, Scripting, Filming, Editing, Motion graphics, Delivery]
order: 4
---
