---
name: Sue Ryan
role: Co-owner, Project Lead
company: Doghouse Media
bio: Runs everything web and digital. Twenty years in IT consultancy, support and development before this.
order: 1
---
